ASPIRE LEARNING HUB - ADVANCED VERSION

Features:
- Classes 6–12 Notes
- Online Tests
- WhatsApp Contact
- Admin Panel (Firebase Auth)
- Mobile Responsive
- Free Deployment via GitHub Pages
- Firebase for storage/database

Deployment:
1. Upload files to GitHub repository.
2. Enable GitHub Pages.
3. Create Firebase project.
4. Enable Authentication + Firestore/Storage.
5. Paste Firebase config in app.js.
